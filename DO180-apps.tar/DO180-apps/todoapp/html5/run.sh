#!/bin/sh

echo "Dont start this directly, use the run.sh scripts from each api back end"

